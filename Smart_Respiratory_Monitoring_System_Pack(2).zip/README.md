# Smart Respiratory Monitoring System

## Files
- `Smart_Respiratory_Monitoring_System.ino` – Arduino IDE code for ESP8266 NodeMCU.
- `Circuit_Diagram.png` – prototype wiring diagram.
- `Prototype_Layout_Illustration.png` – illustrative layout only; it is NOT a real project photo.

## Suggested connections
| Component | ESP8266 pin |
|---|---|
| Flex sensor divider output | A0 |
| OLED SDA | D2 |
| OLED SCL | D1 |
| Buzzer | D5 |
| Red LED (through 220 ohm resistor) | D6 |
| Green LED (through 220 ohm resistor) | D7 |
| GND | Common GND |

Install these Arduino libraries:
- Adafruit GFX Library
- Adafruit SSD1306

## Important
This is a student prototype for respiratory-pattern monitoring. It is not a medical device and should not be used for diagnosis or treatment.

## GitHub upload
Upload the `.ino`, `.png` files and this README as separate files. The ZIP can also be kept as a project backup.
