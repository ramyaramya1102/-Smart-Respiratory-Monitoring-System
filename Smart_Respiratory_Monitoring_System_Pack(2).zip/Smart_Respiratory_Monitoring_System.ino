/*
  Smart Respiratory Monitoring System
  Prototype firmware

  Hardware:
  - ESP8266 NodeMCU (Arduino-compatible)
  - Flex sensor on A0 through a voltage-divider
  - I2C OLED 0.96" (SSD1306): SDA=D2, SCL=D1
  - Buzzer: D5
  - Red LED: D6
  - Green LED: D7

  The flex sensor is used as a simple respiratory-belt sensor.
  A breath is detected when the sensor signal crosses the adaptive
  threshold from low -> high. This is a student prototype and is
  NOT a medical device.
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const int FLEX_PIN = A0;
const int BUZZER_PIN = D5;
const int RED_LED = D6;
const int GREEN_LED = D7;

int baseline = 0;
int thresholdValue = 0;
bool inhaleState = false;

unsigned long lastBreath = 0;
unsigned long breathTimes[6] = {0};
int breathIndex = 0;
int breathsPerMinute = 0;

const int SAMPLE_DELAY = 50;
const unsigned long MIN_BREATH_INTERVAL = 1200; // avoids double counting

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED not detected.");
  }

  // Short baseline calibration while the belt is in a relaxed position.
  long sum = 0;
  for (int i = 0; i < 100; i++) {
    sum += analogRead(FLEX_PIN);
    delay(10);
  }
  baseline = sum / 100;
  thresholdValue = baseline + 35;

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);
  display.println("Smart Respiratory");
  display.println("Monitoring System");
  display.println("Calibrating...");
  display.display();
  delay(1000);
}

void registerBreath() {
  unsigned long now = millis();

  if (lastBreath == 0 || now - lastBreath >= MIN_BREATH_INTERVAL) {
    breathTimes[breathIndex] = now;
    breathIndex = (breathIndex + 1) % 6;
    lastBreath = now;

    int count = 0;
    for (int i = 0; i < 6; i++) {
      if (breathTimes[i] != 0 && now - breathTimes[i] <= 60000UL) {
        count++;
      }
    }
    breathsPerMinute = count;

    tone(BUZZER_PIN, 1800, 60);
  }
}

void updateDisplay(int sensorValue) {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("RESPIRATORY MONITOR");

  display.setCursor(0, 18);
  display.print("Sensor: ");
  display.println(sensorValue);

  display.setCursor(0, 32);
  display.print("Rate: ");
  display.print(breathsPerMinute);
  display.println(" BPM");

  display.setCursor(0, 46);
  if (breathsPerMinute >= 12 && breathsPerMinute <= 20) {
    display.println("Status: NORMAL");
  } else if (breathsPerMinute > 20) {
    display.println("Status: HIGH");
  } else {
    display.println("Status: LOW");
  }

  display.display();
}

void updateAlarm() {
  if (breathsPerMinute > 20 || (breathsPerMinute > 0 && breathsPerMinute < 8)) {
    digitalWrite(RED_LED, HIGH);
    digitalWrite(GREEN_LED, LOW);
    tone(BUZZER_PIN, 2200, 150);
  } else {
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);
  }
}

void loop() {
  int sensorValue = analogRead(FLEX_PIN);

  // Detect a respiratory expansion/contraction event.
  if (!inhaleState && sensorValue > thresholdValue) {
    inhaleState = true;
    registerBreath();
  }

  // Hysteresis prevents repeated detection around the threshold.
  if (inhaleState && sensorValue < thresholdValue - 15) {
    inhaleState = false;
  }

  // Slowly adapt the threshold when the signal is near baseline.
  if (abs(sensorValue - baseline) < 20) {
    baseline = (baseline * 99 + sensorValue) / 100;
    thresholdValue = baseline + 35;
  }

  updateDisplay(sensorValue);
  updateAlarm();

  Serial.print("Sensor=");
  Serial.print(sensorValue);
  Serial.print(", RespiratoryRate=");
  Serial.println(breathsPerMinute);

  delay(SAMPLE_DELAY);
}
