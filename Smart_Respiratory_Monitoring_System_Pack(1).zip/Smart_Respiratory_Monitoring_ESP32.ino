/*
  Smart Respiratory Monitoring and Early Warning System
  Controller: ESP32
  Sensors:
    - Piezoelectric/Flexible respiration sensor -> GPIO34 (ADC)
    - MAX30102 -> I2C (SDA GPIO21, SCL GPIO22)
    - DS18B20 temperature sensor -> GPIO4
  Outputs:
    - 0.96" I2C OLED -> same I2C bus
    - Buzzer -> GPIO25
    - Vibration motor -> GPIO26
    - Silence button -> GPIO27

  NOTE:
  This is an educational prototype. The respiration-rate calculation uses
  a calibrated threshold/peak detector. Accurate clinical SpO2 calculation
  requires a validated MAX30102 SpO2 algorithm and calibration; this sketch
  therefore displays raw MAX30102 signal status rather than inventing a
  clinical SpO2 value.
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include "MAX30105.h"

#define RESP_PIN       34
#define TEMP_PIN        4
#define BUZZER_PIN     25
#define VIBRATION_PIN   26
#define SILENCE_PIN     27

#define I2C_SDA        21
#define I2C_SCL        22

#define SCREEN_WIDTH   128
#define SCREEN_HEIGHT   64
#define OLED_RESET      -1
#define OLED_ADDR       0x3C

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
OneWire oneWire(TEMP_PIN);
DallasTemperature tempSensor(&oneWire);
MAX30105 max30102;

// ---- Respiration calibration ----
// Adjust after observing the piezo sensor signal in Serial Monitor.
const int RESP_THRESHOLD = 1900;
const unsigned long SAMPLE_INTERVAL_MS = 50;
const unsigned long BREATH_WINDOW_MS = 60000UL;

unsigned long lastSample = 0;
unsigned long windowStart = 0;
unsigned long lastBreathTime = 0;
int breathCount = 0;
int respiratoryRate = 0;

bool previousAbove = false;
bool alarmLatched = false;

void showMessage(const String &line1, const String &line2) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 10);
  display.println(line1);
  display.setCursor(0, 30);
  display.println(line2);
  display.display();
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(VIBRATION_PIN, OUTPUT);
  pinMode(SILENCE_PIN, INPUT_PULLUP);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(VIBRATION_PIN, LOW);

  Wire.begin(I2C_SDA, I2C_SCL);

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("OLED not found");
  } else {
    showMessage("Respiratory Monitor", "Initializing...");
  }

  tempSensor.begin();

  if (!max30102.begin(Wire, I2C_SPEED_FAST)) {
    Serial.println("MAX30102/MAX3010x not detected.");
  } else {
    max30102.setup();
    max30102.setPulseAmplitudeRed(0x1F);
    max30102.setPulseAmplitudeIR(0x1F);
  }

  windowStart = millis();
  delay(1200);
}

void updateRespiration() {
  int raw = analogRead(RESP_PIN);
  bool above = raw > RESP_THRESHOLD;

  // Rising-edge peak detection with a refractory period.
  if (above && !previousAbove) {
    if (millis() - lastBreathTime > 1200) {
      breathCount++;
      lastBreathTime = millis();
    }
  }
  previousAbove = above;

  if (millis() - windowStart >= BREATH_WINDOW_MS) {
    respiratoryRate = breathCount;
    breathCount = 0;
    windowStart = millis();
  }

  Serial.print("RespRaw=");
  Serial.print(raw);
  Serial.print(", RR=");
  Serial.println(respiratoryRate);
}

void updateDisplay(float temperatureC, long irValue) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print("RESPIRATORY MONITOR");

  display.setTextSize(2);
  display.setCursor(0, 16);
  display.print("RR:");
  display.print(respiratoryRate);
  display.println(" bpm");

  display.setTextSize(1);
  display.setCursor(0, 40);
  display.print("Temp: ");
  display.print(temperatureC, 1);
  display.println(" C");

  display.setCursor(0, 52);
  display.print("IR:");
  display.print(irValue);

  display.display();
}

void checkAlarm(float temperatureC) {
  // Example prototype thresholds. Do NOT treat these as clinical diagnosis.
  bool abnormalRR = (respiratoryRate > 0 && (respiratoryRate < 10 || respiratoryRate > 30));
  bool temperatureHigh = temperatureC > 38.0;

  if (abnormalRR || temperatureHigh) {
    alarmLatched = true;
  }

  if (digitalRead(SILENCE_PIN) == LOW) {
    alarmLatched = false;
  }

  digitalWrite(BUZZER_PIN, alarmLatched ? HIGH : LOW);
  digitalWrite(VIBRATION_PIN, alarmLatched ? HIGH : LOW);
}

void loop() {
  if (millis() - lastSample < SAMPLE_INTERVAL_MS) return;
  lastSample = millis();

  updateRespiration();

  tempSensor.requestTemperatures();
  float temperatureC = tempSensor.getTempCByIndex(0);

  long irValue = 0;
  if (max30102.available()) {
    irValue = max30102.getIR();
    max30102.nextSample();
  }

  checkAlarm(temperatureC);
  updateDisplay(temperatureC, irValue);
}
