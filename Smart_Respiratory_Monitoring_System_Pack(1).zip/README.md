# Smart Respiratory Monitoring and Early Warning System

## Project
An IoT-enabled wearable prototype for continuous respiratory-pattern monitoring and early warning.

## Hardware
- ESP32 development board
- Flexible / piezoelectric respiration sensor
- MAX30102 SpO2 & heart-rate sensor
- DS18B20 temperature sensor
- 0.96-inch I2C OLED
- Buzzer
- Vibration motor
- Push button for alarm silence
- Li-Po battery + TP4056 charging module (prototype power section)

## Current prototype function
1. Respiration sensor is sampled by the ESP32 ADC.
2. A threshold/peak detector estimates breathing events.
3. Respiratory rate is calculated over a 60-second window.
4. DS18B20 measures body temperature.
5. MAX30102 provides optical IR data for future validated SpO2/heart-rate processing.
6. OLED shows respiratory rate, temperature and IR signal.
7. Buzzer + vibration motor activate for configured abnormal conditions.
8. The ESP32 provides Wi-Fi/BLE capability for a future cloud/mobile dashboard.

## Important
This repository contains an educational prototype implementation. The MAX30102 raw signal is intentionally not converted into a made-up clinical SpO2 number. A validated SpO2/heart-rate algorithm and calibration must be integrated before any medical use.

## Arduino IDE libraries
Install:
- Adafruit GFX Library
- Adafruit SSD1306
- OneWire
- DallasTemperature
- SparkFun MAX3010x Sensor Library

Select an ESP32 board in Arduino IDE and upload the `.ino` file.

## Files
- `Smart_Respiratory_Monitoring_ESP32.ino` — source code
- `Circuit_Diagram.png` — wiring reference
- `Project_Block_Diagram.png` — system architecture
- `Prototype_Concept_Render.png` — concept illustration, NOT a photograph of a real built device
- `components.txt` — component list
- `NOTES.txt` — calibration and safety notes
