# Smart Respiratory Monitoring System

This repository contains the Arduino prototype files for an IoT/embedded respiratory monitoring project.

## Repository contents
- `code/` — Arduino source code
- `circuit_diagram/` — wiring/connection guide
- `project_photos/` — place actual project photographs here
- `docs/` — component list and supporting documentation

## Hardware
Arduino UNO, respiration stretch sensor/belt, MAX30100, SSD1306 I2C OLED, buzzer and LED.

## Note
This is an educational prototype. It is not a certified medical device and should not be used for diagnosis or treatment.
