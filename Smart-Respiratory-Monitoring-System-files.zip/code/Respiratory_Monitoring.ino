/*
  Smart Respiratory Monitoring System
  Arduino UNO prototype

  Sensors:
  - Respiration stretch sensor / belt -> A0
  - MAX30100 pulse-oximeter -> I2C
  - 0.96" SSD1306 OLED -> I2C

  Outputs:
  - Buzzer -> D8
  - Red LED -> D9

  NOTE:
  This is an educational prototype, not a medical device.
*/

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <MAX30100_PulseOximeter.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
PulseOximeter pox;

const int RESP_PIN = A0;
const int BUZZER_PIN = 8;
const int LED_PIN = 9;

// Adjust this threshold after calibration of the stretch sensor.
const int RESP_THRESHOLD = 60;

unsigned long lastBreathTime = 0;
unsigned long lastDisplayTime = 0;
int breathCount = 0;
int breathsPerMinute = 0;
int baseline = 0;

void onBeatDetected() {
  // Callback from MAX30100. No extra action required here.
}

void setup() {
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  Serial.begin(9600);
  Wire.begin();

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED allocation failed");
    while (true);
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Respiratory Monitor");
  display.display();

  if (!pox.begin()) {
    Serial.println("MAX30100 initialization failed");
  } else {
    pox.setOnBeatDetectedCallback(onBeatDetected);
  }

  delay(1000);

  // Simple baseline measurement.
  long sum = 0;
  for (int i = 0; i < 50; i++) {
    sum += analogRead(RESP_PIN);
    delay(10);
  }
  baseline = sum / 50;
}

void loop() {
  pox.update();

  int respValue = analogRead(RESP_PIN);
  int deviation = abs(respValue - baseline);

  // Detect a breathing-cycle peak.
  if (deviation > RESP_THRESHOLD &&
      millis() - lastBreathTime > 1500) {
    breathCount++;
    lastBreathTime = millis();
  }

  // Calculate breath rate approximately every 30 seconds.
  static unsigned long rateWindowStart = millis();
  if (millis() - rateWindowStart >= 30000) {
    breathsPerMinute = breathCount * 2;
    breathCount = 0;
    rateWindowStart = millis();
  }

  float heartRate = pox.getHeartRate();
  float spo2 = pox.getSpO2();

  // Basic educational alert rule.
  bool abnormal = (spo2 > 0 && spo2 < 94) ||
                  (breathsPerMinute > 30);

  digitalWrite(LED_PIN, abnormal ? HIGH : LOW);
  digitalWrite(BUZZER_PIN, abnormal ? HIGH : LOW);

  if (millis() - lastDisplayTime >= 1000) {
    lastDisplayTime = millis();

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("Respiratory Monitor");

    display.print("BPM: ");
    display.println(breathsPerMinute);

    display.print("SpO2: ");
    if (spo2 > 0) {
      display.print(spo2, 0);
      display.println("%");
    } else {
      display.println("--");
    }

    display.print("Heart: ");
    if (heartRate > 0) {
      display.print(heartRate, 0);
      display.println(" bpm");
    } else {
      display.println("--");
    }

    display.print("Status: ");
    display.println(abnormal ? "ALERT" : "Normal");
    display.display();

    Serial.print("Breaths/min: ");
    Serial.print(breathsPerMinute);
    Serial.print(" | SpO2: ");
    Serial.print(spo2);
    Serial.print("% | Heart rate: ");
    Serial.print(heartRate);
    Serial.print(" bpm | Status: ");
    Serial.println(abnormal ? "ALERT" : "Normal");
  }

  // Slow baseline adaptation when the belt is near rest.
  if (deviation < RESP_THRESHOLD / 2) {
    baseline = (baseline * 9 + respValue) / 10;
  }
}
